package pl.edu.pwr.abis.domain.enums;

public enum TypZasobuAplikacyjnego {
    zdjecie,
    film,
    logotyp,
    listReferencyjny
}
