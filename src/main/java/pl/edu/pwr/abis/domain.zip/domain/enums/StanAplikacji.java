package pl.edu.pwr.abis.domain.enums;

public enum StanAplikacji {
    nierozpatrzona,
    przyjeta,
    odrzucona
}