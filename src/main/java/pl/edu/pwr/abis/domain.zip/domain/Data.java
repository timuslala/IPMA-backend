package pl.edu.pwr.abis.domain;

class Data{
    public integer rok;
    public integer miesiac;
    public integer dzien;
}