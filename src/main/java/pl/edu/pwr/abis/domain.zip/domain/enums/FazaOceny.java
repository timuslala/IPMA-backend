package pl.edu.pwr.abis.domain.enums;

public enum FazaOceny {
    indywidualna,
    wstepna,
    wizytaStudyjna,
    koncowa
}
