package pl.edu.pwr.abis.domain.enums;

public enum TypWydarzenia {
    posiedzenieJury,
    webinarium.
    wylonieniaZwyciescow,
    wreczenieNagrod,
    inne
}