package pl.edu.pwr.abis.domain.enums;

public enum WynikAplikacji {
    zwycięsta,
    srebrnyFinalista,
    brązowyFinalista,
    finalista,
    uczestnik,
    odpadł
}