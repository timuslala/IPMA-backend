package pl.edu.pwr.abis.domain.enums;

public enum StanDanych {
    doWeryfikacji,
    zweryfikowane, 
    niezweryfikowane
}