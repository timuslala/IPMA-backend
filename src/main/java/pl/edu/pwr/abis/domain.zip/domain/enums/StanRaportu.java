package pl.edu.pwr.abis.domain.enums;

public enum StanRaportu {
    wersjaRobocza,
    zlozony,
    przyjety,
    odrzucony,
    doPoprawy
}