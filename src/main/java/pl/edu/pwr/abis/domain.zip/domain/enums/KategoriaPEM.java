package pl.edu.pwr.abis.domain.enums;

public enum KategoriaPEM {
    ludzieCele,
    procesyZasoby,
    rezultatyProjektu
}