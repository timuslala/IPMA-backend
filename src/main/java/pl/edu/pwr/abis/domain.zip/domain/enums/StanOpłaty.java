package pl.edu.pwr.abis.domain.enums;

public enum StanOpłaty {
    niepokryta,
    odroczona,
    pokryta
}