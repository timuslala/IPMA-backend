package pl.edu.pwr.abis.domain.enums;

public enum StanRaportuAplikacyjnego {
    wersjaRobocza,
    zlozony,
    przyjety,
    odrzucony
}