package pl.edu.pwr.abis.domain.enums;

public enum TypWebinarium {
    dlaAplikantow,
    dlaEkspertowIPMA,
    dlaAsesorowWiodacych,
    inne
}