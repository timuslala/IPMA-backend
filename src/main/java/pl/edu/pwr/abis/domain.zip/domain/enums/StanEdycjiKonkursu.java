package pl.edu.pwr.abis.domain.enums;

public enum StanEdycjiKonkursu {
    planowana,
    wTrakcie,
    zakonczona,
    odwolana
}