package pl.edu.pwr.abis.domain.enums;

public enum StanKonta {
    aktywne,
    nieaktywne
}